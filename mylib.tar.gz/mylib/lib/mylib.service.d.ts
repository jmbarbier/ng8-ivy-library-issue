export declare class MylibService {
    constructor();
}
