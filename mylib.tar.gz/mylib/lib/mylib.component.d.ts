import { OnInit } from '@angular/core';
export declare class MylibComponent implements OnInit {
    works: boolean;
    constructor();
    ngOnInit(): void;
}
