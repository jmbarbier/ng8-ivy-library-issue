import { __decorate, __metadata } from 'tslib';
import { Component, ɵɵdefineInjectable, Injectable, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

let MylibComponent = class MylibComponent {
    constructor() {
        this.works = true;
    }
    ngOnInit() {
    }
};
MylibComponent = __decorate([
    Component({
        selector: 'lib-mylib',
        template: `
    <p *ngIf="works">
      mylib works!
    </p>
  `
    }),
    __metadata("design:paramtypes", [])
], MylibComponent);

let MylibService = class MylibService {
    constructor() { }
};
MylibService.ngInjectableDef = ɵɵdefineInjectable({ factory: function MylibService_Factory() { return new MylibService(); }, token: MylibService, providedIn: "root" });
MylibService = __decorate([
    Injectable({
        providedIn: 'root'
    }),
    __metadata("design:paramtypes", [])
], MylibService);

let MylibModule = class MylibModule {
};
MylibModule = __decorate([
    NgModule({
        declarations: [MylibComponent],
        imports: [
            CommonModule
        ],
        exports: [MylibComponent]
    })
], MylibModule);

/*
 * Public API Surface of mylib
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MylibComponent, MylibModule, MylibService };
//# sourceMappingURL=mylib.js.map
