import { __decorate, __metadata } from 'tslib';
import { Component, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

let MylibComponent = class MylibComponent {
    constructor() {
        this.works = true;
    }
    ngOnInit() {
    }
};
MylibComponent = __decorate([
    Component({
        selector: 'lib-mylib',
        template: `
    <p *ngIf="works">
      mylib works!
    </p>
  `
    }),
    __metadata("design:paramtypes", [])
], MylibComponent);

let MylibModule = class MylibModule {
};
MylibModule = __decorate([
    NgModule({
        declarations: [MylibComponent],
        imports: [
            CommonModule
        ],
        exports: [MylibComponent]
    })
], MylibModule);

/*
 * Public API Surface of mylib
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MylibComponent, MylibModule };
//# sourceMappingURL=mylib.js.map
