export declare class MylibModule {
}
