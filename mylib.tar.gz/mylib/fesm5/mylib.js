import { __decorate, __metadata } from 'tslib';
import { Component, ɵɵdefineInjectable, Injectable, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

var MylibComponent = /** @class */ (function () {
    function MylibComponent() {
        this.works = true;
    }
    MylibComponent.prototype.ngOnInit = function () {
    };
    MylibComponent = __decorate([
        Component({
            selector: 'lib-mylib',
            template: "\n    <p *ngIf=\"works\">\n      mylib works!\n    </p>\n  "
        }),
        __metadata("design:paramtypes", [])
    ], MylibComponent);
    return MylibComponent;
}());

var MylibService = /** @class */ (function () {
    function MylibService() {
    }
    MylibService.ngInjectableDef = ɵɵdefineInjectable({ factory: function MylibService_Factory() { return new MylibService(); }, token: MylibService, providedIn: "root" });
    MylibService = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [])
    ], MylibService);
    return MylibService;
}());

var MylibModule = /** @class */ (function () {
    function MylibModule() {
    }
    MylibModule = __decorate([
        NgModule({
            declarations: [MylibComponent],
            imports: [
                CommonModule
            ],
            exports: [MylibComponent]
        })
    ], MylibModule);
    return MylibModule;
}());

/*
 * Public API Surface of mylib
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MylibComponent, MylibModule, MylibService };
//# sourceMappingURL=mylib.js.map
